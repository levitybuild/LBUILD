# Lionel App - Complete Android & Google Play Release Package
Package ID: com.lourdjvke.lionel
Version: 1.0.0 (Version Code: 101)
Timestamp: 2026-10-11T16:50:11.046Z

## Included Files in this ZIP:
1. **lionel.apk** (or lionel_app_signed_release.apk) - Standalone Signed Production APK
2. **lionel.aab** (or lionel_app_production_playstore.aab) - Production Android App Bundle for Google Play Store
3. **larp_release.keystore** - RSA-2048 signing certificate & key (SHA-256: 4C:91:E2:B0:81:4A:9F:77:3B:18:65:C2:5E:AA:91:02)
4. **release_info.json** - Cryptographic credentials, key alias, and fingerprints
5. **larp-bridge.js** - Native JavaScript runtime bridge
