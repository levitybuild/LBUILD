# Roulette - Complete Android & Google Play Release Package
Package ID: com.casino.roulette
Version: 1.0.0 (Version Code: 101)
Timestamp: 2026-10-11T16:42:27.077Z

## Included Files in this ZIP:
1. **lionel.apk** (or roulette_signed_release.apk) - Standalone Signed Production APK
2. **lionel.aab** (or roulette_production_playstore.aab) - Production Android App Bundle for Google Play Store
3. **larp_release.keystore** - RSA-2048 signing certificate & key (SHA-256: 13:C6:63:2C:C5:AF:48:9F:48:B3:4A:23:FD:E6:A8:9B:F7:C2:6E:8F:EB:CA:3D:50:98:9D:C0:6A:8E:00:C5:BA)
4. **release_info.json** - Cryptographic credentials, key alias, and fingerprints
5. **larp-bridge.js** - Native JavaScript runtime bridge
