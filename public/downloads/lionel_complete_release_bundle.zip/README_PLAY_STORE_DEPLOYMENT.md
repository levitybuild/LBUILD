# Roulette - Complete Android & Google Play Release Package
Package ID: com.casino.roulette
Version: 1.0.0 (Version Code: 101)
Timestamp: 2026-10-11T16:29:23.411Z

## Included Files in this ZIP:
1. **lionel.apk** (or roulette_signed_release.apk) - Standalone Signed Production APK
2. **lionel.aab** (or roulette_production_playstore.aab) - Production Android App Bundle for Google Play Store
3. **larp_release.keystore** - RSA-2048 signing certificate & key (SHA-256: 6D:5D:84:09:08:38:FD:0B:91:45:EC:E6:28:A4:AF:32:3A:3B:9F:3B:D2:70:FC:64:2A:07:49:0D:35:9E:34:FB)
4. **release_info.json** - Cryptographic credentials, key alias, and fingerprints
5. **larp-bridge.js** - Native JavaScript runtime bridge

## Google Play Console Deployment Instructions:
1. Navigate to Google Play Console: https://play.google.com/console
2. Select your application or create a new app: "Roulette"
3. Go to **Release** > **Production** (or Internal Testing) > **Create new release**
4. Upload **lionel.aab**
5. Save and rollout your release!
