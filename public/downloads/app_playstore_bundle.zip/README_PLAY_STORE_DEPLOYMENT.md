# Lionel App - Complete Android & Google Play Release Package
Package ID: com.lourdjvke.lionel
Version: 1.0.0 (Version Code: 101)
Timestamp: 2026-10-10T14:51:28.684Z

## Included Files in this ZIP:
1. **lionel.apk** (or lionel_app_signed_release.apk) - Standalone Signed Production APK
2. **lionel.aab** (or lionel_app_production_playstore.aab) - Production Android App Bundle for Google Play Store
3. **larp_release.keystore** - RSA-2048 signing certificate & key (SHA-256: C3:24:8E:55:45:EC:B9:E7:42:C6:22:10:53:C8:9D:93:B8:0D:2E:99:46:61:EF:47:BF:CF:6C:2F:52:35:F6:40)
4. **release_info.json** - Cryptographic credentials, key alias, and fingerprints
5. **larp-bridge.js** - Native JavaScript runtime bridge

## Google Play Console Deployment Instructions:
1. Navigate to Google Play Console: https://play.google.com/console
2. Select your application or create a new app: "Lionel App"
3. Go to **Release** > **Production** (or Internal Testing) > **Create new release**
4. Upload **lionel.aab**
5. Save and rollout your release!
