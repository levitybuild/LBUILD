package com.lourdjvke.lionel;

import android.app.Activity;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Vibrator;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.widget.FrameLayout;
import android.graphics.Color;
import android.content.ComponentName;
import android.content.Context;
import android.content.pm.PackageManager;

public class MainActivity extends Activity {
    private WebView webView;
    private View splashView;
    private Handler mainHandler;
    private static final String DEFAULT_THEME_COLOR = "#D97757";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mainHandler = new Handler(Looper.getMainLooper());

        // Paint the top status bar with the page theme color immediately (Never black!)
        applyThemeColor(DEFAULT_THEME_COLOR);

        // Stay Awake: keep screen on
        try {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        } catch(Exception ignored) {}

        // Layout container
        FrameLayout rootLayout = new FrameLayout(this);
        rootLayout.setLayoutParams(new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        // WebView configuration
        webView = new WebView(this);
        webView.setLayoutParams(new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowFileAccessFromFileURLs(true);
        settings.setAllowUniversalAccessFromFileURLs(true);
        settings.setDatabaseEnabled(true);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);

        // Native Bridge Javascript Interface
        webView.addJavascriptInterface(new LarpNativeInterface(), "LarpNative");

        // WebChromeClient enables JavaScript alerts, confirms, console, and interactive DOM features
        webView.setWebChromeClient(new WebChromeClient());

        // Splash screen view matching theme background
        splashView = new View(this);
        splashView.setLayoutParams(new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        try {
            splashView.setBackgroundColor(Color.parseColor("#FAF8F5"));
        } catch(Exception e) {
            splashView.setBackgroundColor(Color.WHITE);
        }

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                if (url != null && (url.startsWith("file://") || url.startsWith("data:") || url.startsWith("javascript:"))) {
                    return false; // Load inside WebView for local multi-page navigation
                }
                return false;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                
                // Read the page's <meta name="theme-color"> and sync status bar
                view.evaluateJavascript(
                    "(function() { var ms = document.getElementsByTagName('meta'); for(var i=0; i<ms.length; i++) { if(ms[i].name === 'theme-color') return ms[i].content; } return ''; })()",
                    new android.webkit.ValueCallback<String>() {
                        @Override
                        public void onReceiveValue(String value) {
                            if (value != null && !value.equals("null") && !value.isEmpty()) {
                                String clean = value.replace('\"', ' ').trim();
                                if (clean.startsWith("#")) {
                                    applyThemeColor(clean);
                                }
                            }
                        }
                    }
                );

                
                mainHandler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        hideSplash();
                    }
                }, 400);
                
            }
        });

        rootLayout.addView(webView);
        rootLayout.addView(splashView);
        setContentView(rootLayout);

        // Load offline bundled web app
        webView.loadUrl("file:///android_asset/public/index.html");
    }

    /**
     * Physical & Gesture Back Button Navigation:
     * If the user navigated across internal pages or history states, go back inside WebView.
     * Only exit the app if at the root page.
     */
    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    /**
     * Paints the native Android Status Bar and Navigation Bar to match the page's theme-color,
     * calculating perceived luminance so time, battery, and icons are always crisp and legible.
     */
    public void applyThemeColor(final String hexColor) {
        if (hexColor == null || hexColor.trim().isEmpty()) return;
        mainHandler.post(new Runnable() {
            @Override
            public void run() {
                try {
                    String clean = hexColor.trim();
                    if (!clean.startsWith("#")) clean = "#" + clean;
                    int color = Color.parseColor(clean);
                    Window window = getWindow();
                    window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
                    window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
                    window.setStatusBarColor(color);
                    window.setNavigationBarColor(color);

                    // Perceived luminance formula (ITU-R BT.709)
                    double luma = 0.299 * Color.red(color) + 0.587 * Color.green(color) + 0.114 * Color.blue(color);
                    boolean isLight = luma > 150;

                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        View decor = window.getDecorView();
                        int flags = decor.getSystemUiVisibility();
                        if (isLight) {
                            flags |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
                            if (Build.VERSION.SDK_INT >= 26) {
                                flags |= 0x00000010; // SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
                            }
                        } else {
                            flags &= ~View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
                            if (Build.VERSION.SDK_INT >= 26) {
                                flags &= ~0x00000010;
                            }
                        }
                        decor.setSystemUiVisibility(flags);
                    }
                } catch (Exception ignored) {}
            }
        });
    }

    private void hideSplash() {
        if (splashView != null && splashView.getParent() != null) {
            splashView.animate().alpha(0f).setDuration(300).withEndAction(new Runnable() {
                @Override
                public void run() {
                    if (splashView != null && splashView.getParent() != null) {
                        ((FrameLayout) splashView.getParent()).removeView(splashView);
                    }
                }
            });
        }
    }

    /**
     * Native JavaScript Bridge Interface exposed to Web DOM as window.LarpNative
     */
    public class LarpNativeInterface {
        @JavascriptInterface
        public void setThemeColor(final String hexColor) {
            applyThemeColor(hexColor);
        }

        @JavascriptInterface
        public void setFullscreen(final boolean enable) {
            // Handled via theme-color and safe insets to prevent black bars
        }

        @JavascriptInterface
        public void setKeepAwake(final boolean enable) {
            mainHandler.post(new Runnable() {
                @Override
                public void run() {
                    try {
                        if (enable) {
                            getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                        } else {
                            getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                        }
                    } catch (Exception ignored) {}
                }
            });
        }

        @JavascriptInterface
        public void hideSplashScreen() {
            mainHandler.post(new Runnable() {
                @Override
                public void run() {
                    hideSplash();
                }
            });
        }

        @JavascriptInterface
        public void setIcon(final String variantId) {
            switchAppIcon(variantId);
        }

        @JavascriptInterface
        public void haptic(String style) {
            try {
                Vibrator v = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
                if (v != null) {
                    long duration = "HEAVY".equalsIgnoreCase(style) ? 40 : 20;
                    v.vibrate(duration);
                }
            } catch(Exception ignored) {}
        }
    }

    /**
     * Duolingo-style Dynamic App Icon Swapping using Android <activity-alias>.
     * The base .MainActivity is ALWAYS kept enabled.
     * The target alias is enabled FIRST, then previous aliases are disabled.
     */
    private void switchAppIcon(final String targetVariantId) {
        mainHandler.post(new Runnable() {
            @Override
            public void run() {
                try {
                    PackageManager pm = getPackageManager();
                    String pkg = getPackageName();

                    String target = (targetVariantId == null || targetVariantId.trim().isEmpty())
                        ? "default"
                        : targetVariantId.trim();
                    final String resolvedTarget = target;

                    // All configured alias variant IDs (including default)
                    String[] allVariantIds = new String[] {
                        "default",
                        "streak_fire", "stealth_dark"
                    };

                    // 1. Enable target alias FIRST
                    ComponentName targetAlias = new ComponentName(pkg, pkg + ".MainActivity_" + resolvedTarget);
                    pm.setComponentEnabledSetting(
                        targetAlias,
                        PackageManager.COMPONENT_ENABLED_STATE_ENABLED,
                        PackageManager.DONT_KILL_APP
                    );

                    // 2. Disable all other aliases (NEVER touch MainActivity itself!)
                    for (String variantId : allVariantIds) {
                        if (!variantId.equalsIgnoreCase(resolvedTarget)) {
                            ComponentName otherAlias = new ComponentName(pkg, pkg + ".MainActivity_" + variantId);
                            pm.setComponentEnabledSetting(
                                otherAlias,
                                PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
                                PackageManager.DONT_KILL_APP
                            );
                        }
                    }

                    android.widget.Toast.makeText(
                        MainActivity.this,
                        "App icon updated to " + resolvedTarget.replace("_", " ") + "!",
                        android.widget.Toast.LENGTH_SHORT
                    ).show();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }
}
